package com.reConnect.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class UserDAO {
	private Connection connection = null;
	private PreparedStatement ps = null; 
	private ResultSet rs = null; 
	//private UserDAO updater;
	
	private Connection getConnection() throws SQLException{
		Connection conn;
		ConnectionDB connDB = new ConnectionDB();
		conn = connDB.connection();
		return conn;
	}
	
	public ArrayList<UserVO> obtainAllUsers(){
		UserVO userVOAux;
		ArrayList<UserVO> userVO = null;
		try {
			userVO = new ArrayList<UserVO>();
			connection = getConnection();
			ps = connection.prepareStatement("SELECT * FROM user");
			rs = ps.executeQuery();
			System.out.println("Connected sucessfully");
			while(rs.next()) {
				userVOAux = new UserVO();
				userVOAux.setUid(rs.getInt(1));
				userVOAux.setUsername(rs.getString(2));
				userVOAux.setEmail(rs.getString(3));
				userVOAux.setPassword(rs.getString(4));
				userVOAux.setName(rs.getString(5));
				userVOAux.setSurname(rs.getString(6));
				userVO.add(userVOAux);
			}
			return userVO;
		} catch (SQLException e) {
			// TODO: handle exception
		} finally {
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(connection != null) connection.close();
			} catch (SQLException e) {
				System.out.println("SQLException ERROR");
			} 
			catch (Exception e) {
				System.out.println("ERROR");
			} 
		}
		return userVO;
	}
	
	public void createUser(UserVO user) {
		try {
			connection = getConnection();
			PreparedStatement psCreateUser = connection.prepareStatement("INSERT INTO user(USERNAME, EMAIL, PASSWORD, NAME, SURNAME)"
					+ "VALUES(?, ?, ?, ?, ?)");
			psCreateUser.setString(1, user.getUsername());
			psCreateUser.setString(2, user.getEmail());
			psCreateUser.setString(3, user.getPassword());
			psCreateUser.setString(4, user.getName());
			psCreateUser.setString(5, user.getSurname());
			psCreateUser.executeUpdate();
		} catch (SQLException e) {
			Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("ERROR!");
            alert.setHeaderText("Hi ha hagut un problema amb la creació de l'usuari");
            alert.setContentText("Prova un altre nom d'usuari o correu electrònic");
            alert.showAndWait();
		} finally {
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(connection != null) connection.close();
			} catch (SQLException e) {
				System.out.println("SQLException ERROR");
			} 
			catch (Exception e) {
				System.out.println("ERROR");
			} 
		}
	}
}
